/*
package library.management.system;
import java.sql.*;

public class conn{
    public static void main(String[] args) {


        Connection c;
        Statement s;

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibMgmSys_ProjectV2?characterEncoding=latin1", "root", "password");
            s =c.createStatement();


        }catch(Exception e){
            System.out.println(e);
        }
    }
}
*/
